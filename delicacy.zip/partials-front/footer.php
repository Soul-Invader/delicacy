
    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By: <a href="https://linkedin.com/in/payal-wadkar-a6a50521b/" class="my-profile">Payal Wadkar</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>