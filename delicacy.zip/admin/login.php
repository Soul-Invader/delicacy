<?php include('../config/constants.php'); ?>
<html>
    <head>
        <title>
            Login - Food Order System
        </title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>

    <body class="login-background">
        <div class="login  login-form">
            <h1 class="text-center">Login</h1><br>

            <?php 
                if(isset($_SESSION['login']))
                {
                    echo $_SESSION['login'];
                    unset($_SESSION['login']);
                }

                if(isset($_SESSION['no-login-message']))
                {
                    echo $_SESSION['no-login-message'];
                    unset($_SESSION['no-login-message']);
                }

            ?>

        <br>


        <!-- Login Form Starts Here --> 
        <form action="" method="post" class="text-center">
            <b>Username:</b> <br>
            <input type="text" name="username" placeholder="Enter Username" id=""><br><br>
            <b>Password:</b> <br>
            <input type="password" name="password" placeholder="Enter Password" id=""> <br><br>
            <input type="submit" value="Login" name="submit" class="btn-primary">
        </form><br>

            <p class="text-center">
                <b>Created By</b> - <a class="my-profile" href="https://www.linkedin.com/in/payal-wadkar-a6a50521b/">Payal Wadkar</a>
            </p>
        </div>
    </body>
</html>

<?php 

    if(isset($_POST['submit']))
    {
        $username=mysqli_real_escape_string($conn,$_POST['username']);
        $password=mysqli_real_escape_string($conn,md5($_POST['password']));

        $sql="SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";
        $res=mysqli_query($conn,$sql);

        $count=mysqli_num_rows($res);
        if($count==1)
        {
            $_SESSION['login']="<div class='success text-center'>Login Successful</div>";
            $_SESSION['user']=$username; //ells if user is loggged on this will be unset only when usr logs out
            header("location:".SITEURL."admin/");
        }
        else
        {
            $_SESSION['login']="<div class='error text-center'>Username or Password did not match</div>";
            header("location:".SITEURL."admin/login.php");
        }

    }


?>