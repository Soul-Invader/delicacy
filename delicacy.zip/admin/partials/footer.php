
        <!-- Footer Section Starts -->
        <div class="footer">
            <div class="wrapper">
                <p class="text-center">2022 All Rights Reserved, Wow Restaurent, Developed By - <a href="https://linkedin.com/in/payal-wadkar-a6a50521b/">Payal Wadkar</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->
    </body>
</html>