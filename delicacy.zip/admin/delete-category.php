<?php include('../config/constants.php');
    //check if id and img name is set or not bcs no one should go to delete category page without id and image_name set
    if(isset($_GET['id']) AND isset($_GET['image_name']))
    {
        $id=$_GET['id'];
        $image_name=$_GET['image_name'];

        //remove img if avail
        if($image_name!="")
        {
            $path="../images/category/".$image_name;
            $remove=unlink($path);  //remove file

            if($remove==false)
            {
                $_SESSION['remove']="<div class='error'>Failed to remove category</div>";
                header("location:".SITEURL."admin/manage-category.php");
                die();
            }
        }
        $sql="DELETE FROM tbl_category WHERE id=$id";
        $res=mysqli_query($conn,$sql);

        if($res==true)
        {
            $_SESSION['delete']="<div class='success'>Category Deleted Successfully</div>";
            header("location:".SITEURL."admin/manage-category.php");
        }
        else
        {
            $_SESSION['delete']="<div class='error'>Failed to delete category</div>";
            header("location:".SITEURL."admin/manage-category.php");
        }


    }
    else
    {
        header("location:".SITEURL."admin/manage-category.php");
    }

?>