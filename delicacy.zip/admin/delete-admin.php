<?php include("../config/constants.php");
    //1.get id of admin to be deleted
    $id=$_GET['id'];

    //2.create sql query to delete admin
    $sql="delete from tbl_admin where id=$id";
    $res=mysqli_query($conn,$sql);

    //3.redirect to manage admin page with message(success/error)
    if($res==TRUE)
    {
        $_SESSION['delete']="<div class='success'>Admin deleted successfully</div>";
        header("location:".SITEURL."admin/manage-admin.php");
    }
    else
    {
        $_SESSION['delete']="<div class='error'>Failed to delete admin.</div>";
        header("location:".SITEURL."admin/manage-admin.php");
    }

    

?>